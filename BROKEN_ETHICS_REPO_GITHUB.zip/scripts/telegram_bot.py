import telegram
bot = telegram.Bot(token='8122435941:AAE23hY2bHkNymM-Et8MsENoV90qwbYe17c')
bot.send_message(chat_id='7579205183', text='Server started.')
